FEED READER TESTING PROJECT:

INTRODUCTION:

  •In this project we have to check the create the test cases for index.html.
  •[Jasmine](http://jasmine.github.io/) was used to check the working.

STARTUP:

  •Review the Feed Reader Testing [Project Rubric](https://review.udacity.com/#!/projects/3442558598/rubric)
  •Download the github repo (http://github.com/udacity/frontend-nanodegree-feedreader).
  •Unzip the ZIP file.
  •Open the index.html in your browser
  •Use feedreder.js for your test creation.    
